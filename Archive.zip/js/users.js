// Data akun pengguna aplikasi dumaikota
const users = [
  // Kecamatan
  { username: "cdk", password: "dumaikota", role: "CAMAT" },
  { username: "sekcam", password: "sekcam", role: "SEKCAM" },
  { username: "kasi_trantib", password: "kasi_trantib", role: "KASI_TRANTIB" },
  { username: "kasi_pem", password: "kasi_pem", role: "KASI_PEMERINTAHAN" },
  { username: "kasi_pm", password: "kasi_pm", role: "KASI_PEMBERDAYAAN" },

  // Kelurahan Sukajadi
  { username: "lurah_sukajadi", password: "lurah_sukajadi", role: "LURAH_SUKAJADI" },
  { username: "sekel_sukajadi", password: "sekel_sukajadi", role: "SEKEL_SUKAJADI" },

  // Kelurahan Bintan
  { username: "lurah_bintan", password: "lurah_bintan", role: "LURAH_BINTAN" },
  { username: "sekel_bintan", password: "sekel_bintan", role: "SEKEL_BINTAN" },

  // Kelurahan Dumai Kota
  { username: "lurah_dumaikota", password: "lurah_dumaikota", role: "LURAH_DUMAIKOTA" },
  { username: "sekel_dumaikota", password: "sekel_dumaikota", role: "SEKEL_DUMAIKOTA" },

  // Kelurahan Rimba Sekampung
  { username: "lurah_rimbas", password: "lurah_rimbas", role: "LURAH_RIMBASEKAMPUNG" },
  { username: "sekel_rimbas", password: "sekel_rimbas", role: "SEKEL_RIMBASEKAMPUNG" },

  // Kelurahan Laksamana
  { username: "lurah_laksamana", password: "lurah_laksamana", role: "LURAH_LAKSAMANA" },
  { username: "sekel_laksamana", password: "sekel_laksamana", role: "SEKEL_LAKSAMANA" }
];
