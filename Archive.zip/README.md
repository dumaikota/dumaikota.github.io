# Aplikasi Kontrol Manajemen Camat Dumai Kota

Struktur dasar aplikasi versi bersih (tanpa data).  
Folder utama:
- `css/` → gaya umum
- `js/` → skrip navigasi dan modul
- `pages/` → halaman setiap modul
- `data/` → tempat penyimpanan data JSON

Versi ini siap dikembangkan untuk modul:
- 📅 Agenda Harian Pejabat  
- 📨 Disposisi Surat (Manual & Srikandi)  
- 🧾 Nota Dinas  
- 🧭 Surat Tugas  
